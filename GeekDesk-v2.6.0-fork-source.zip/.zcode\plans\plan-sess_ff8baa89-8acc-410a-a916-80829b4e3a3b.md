# GeekDesk 二级分类功能实现计划（方案 A：右侧分组标签行）

## 设计总览
在左侧菜单（一级分类）保持不变的前提下，为每个菜单内部增加**二级分组**。右侧图标卡片顶部显示一排药丸形分组标签：`⟨默认⟩ ⟨游戏⟩ ⟨启动器⟩ ⟨+⟩`。点击标签切换显示对应图标组——**复用现有的 `SelectedMenuIcons` 引用切换机制**（与点击左侧菜单同一机制），零过滤、零额外线程。无分组时整行自动隐藏，界面与现状完全一致。

## 数据模型（向后兼容，BinaryFormatter）
- 新建 `ViewModel\SubGroupInfo.cs`：`[Serializable]`，字段 `SubName`、`SubId`(GUID)、`IconList`（与 MenuInfo 同构，含 INPC + NoWrite 惯例）。
- `MenuInfo` 新增字段 `SubGroups`（`ObservableCollection<SubGroupInfo>`），**getter 空保护**（`if null → new`，照搬 `AppData.MenuList` 的既有惯例；旧 Data 文件反序列化后该字段为 null，getter 兜底，不抛异常）。
- `IconInfo` 新增 `SubGroupId`（string，null = 未分组，在"默认"组显示）。只增不改，旧 `Data`/`Data-GD-260908.bak` 直接可读。

## UI（RightCardControl）
- `WrapCard` 内 `WrapUFG` 上方插入一行分组标签条（`hc:UniformSpacingPanel` + RadioButton 样式芯片，沿用 OtherControl 排序按钮的既有样式惯例），绑定 `SubGroups` + "默认"项 + "＋"新建项。
- `SelectedSubGroupIndex`（AppConfig 新增 `[NonSerialized]` 运行时属性）记录当前选中标签；切换菜单/搜索时重置。
- LINK 关联菜单（文件夹同步菜单）不启用分组：标签行隐藏。
- 标签右键：重命名（复用 BGNmaeDialog 模式做输入弹窗）/ 删除（组内图标自动退回"默认"，不丢失）/ 上移 / 下移。

## 交互
- **拖拽入组**：图标拖到标签上 → `IconList.Remove` + 目标组 `IconList.Add`（拖到"默认"= 移出分组）。沿用 `ListBoxDragDropManager` 携带 IconInfo 的现有 DataObject 机制，在标签上注册 Drop 处理器。
- **右键入组**：图标右键菜单新增"移动到分组"MenuItem，子菜单动态列出该菜单所有分组（在容器打开时动态填充）。
- 新建分组弹窗：克隆 `BGNmaeDialog` 结构（TextBox + 保存）。
- 标签行可见性：`SubGroups.Count > 0` 时显示（Count2VisibleConvert 已有转换器可复用）。

## 兼容性改动点（逐一核对过的横切清单）
| 位置 | 改动 |
|---|---|
| `LeftCardControl.Menu_SelectionChanged`(xaml.cs:411) | 切换菜单时重置分组选择为"默认"并刷新标签行 |
| `CommonCode.SortIconList`(352) | 排序范围 = 默认组 + 各分组（按组内排序，不打乱分组归属） |
| `RightCardControl` 拖拽管理器(47) | 保持绑定真实列表引用（默认组或当前组），索引语义不变 |
| `Wrap_Drop`/`Menu_Drop`/URL/系统项目添加 | 新图标进入"当前显示的组"（默认=未分组） |
| `FileWatcher` LINK 同步 | 不涉及（LINK 菜单无分组） |
| `MainWindow.SearchDelay`(205) | 搜索遍历扩展到 SubGroups（分组内图标也能被搜到） |
| `RelativePathThread`(19) | 遍历扩展到 SubGroups |
| `PasswordDialog` 解锁 | 解锁后显示默认组 + 标签行（加密仅作用于整个菜单，语义不变） |
| 批量模式/滚轮切换/悬停切换 | 无需改动（仍操作真实列表引用） |

## 持久化
所有变更通过既有 `OnPropertyChanged → SaveAppData` 自动落盘；分组集合内容变更处显式调用 `SaveAppData`（同 `Menu_Drop` 惯例）。

## 构建与验收
1. NuGet 还原 + msbuild 构建（.NET Framework 4.7.2）。
2. 在临时目录用**你的 `Data-GD-260908.bak` 副本**验证旧数据加载无损。
3. 运行程序：建组、拖拽入组、右键移动、删除组退回、重启后持久化、旧备份恢复，截图验收。